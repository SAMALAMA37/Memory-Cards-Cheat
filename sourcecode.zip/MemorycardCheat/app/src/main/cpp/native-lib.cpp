#include <jni.h>
#include <android/bitmap.h>
#include <cmath>

struct Color {
    uint8_t r, g, b;
};

extern "C" JNIEXPORT void JNICALL
Java_com_example_memorycardhelper_FloatingWidgetService_compareBitmapsNative(
        JNIEnv *env,
jobject /* this */,
jobject bmp1,
        jobject bmp2,
jobject bmp_diff,
        jint threshold) {

AndroidBitmapInfo info1;
AndroidBitmap_getInfo(env, bmp1, &info1);

void *pixels1, *pixels2, *pixels_diff;
AndroidBitmap_lockPixels(env, bmp1, &pixels1);
AndroidBitmap_lockPixels(env, bmp2, &pixels2);
AndroidBitmap_lockPixels(env, bmp_diff, &pixels_diff);

int width = info1.width;
int height = info1.height;
auto *p1 = static_cast<uint32_t *>(pixels1);
auto *p2 = static_cast<uint32_t *>(pixels2);
auto *p_diff = static_cast<uint32_t *>(pixels_diff);

for (int i = 0; i < width * height; ++i) {
uint32_t pixel1_8888 = p1[i];
uint32_t pixel2_8888 = p2[i];

if (pixel1_8888 != pixel2_8888) {
Color c1 = { static_cast<uint8_t>((pixel1_8888 >> 16) & 0xFF), static_cast<uint8_t>((pixel1_8888 >> 8) & 0xFF), static_cast<uint8_t>((pixel1_8888) & 0xFF) };
Color c2 = { static_cast<uint8_t>((pixel2_8888 >> 16) & 0xFF), static_cast<uint8_t>((pixel2_8888 >> 8) & 0xFF), static_cast<uint8_t>((pixel2_8888) & 0xFF) };

if (std::abs(c1.r - c2.r) + std::abs(c1.g - c2.g) + std::abs(c1.b - c2.b) > threshold) {
// *** THE FIX IS HERE ***
// Instead of writing solid red, write the actual pixel from the NEW image.
// This makes the difference visible.
p_diff[i] = pixel2_8888;
} else {
p_diff[i] = 0x00000000; // Transparent
}
} else {
p_diff[i] = 0x00000000; // Transparent
}
}

AndroidBitmap_unlockPixels(env, bmp1);
AndroidBitmap_unlockPixels(env, bmp2);
AndroidBitmap_unlockPixels(env, bmp_diff);
}