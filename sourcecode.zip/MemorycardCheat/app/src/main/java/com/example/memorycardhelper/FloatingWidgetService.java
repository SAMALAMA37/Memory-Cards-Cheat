package com.example.memorycardhelper;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.PixelFormat;
import android.hardware.display.DisplayManager;
import android.hardware.display.VirtualDisplay;
import android.media.Image;
import android.media.ImageReader;
import android.media.projection.MediaProjection;
import android.media.projection.MediaProjectionManager;
import android.os.Build;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.util.DisplayMetrics;
import android.util.Log;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.MotionEvent;
import android.view.View;
import android.view.WindowManager;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.Toast;

import androidx.core.app.NotificationCompat;

import java.nio.ByteBuffer;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class FloatingWidgetService extends Service {

    static {
        System.loadLibrary("native-lib");
    }
    public native void compareBitmapsNative(Bitmap bmp1, Bitmap bmp2, Bitmap bmpDiff, int threshold);

    private static final String TAG = "FloatingWidgetService";
    private static final Bitmap.Config BITMAP_CONFIG = Bitmap.Config.ARGB_8888;
    private static final int PIXEL_DIFFERENCE_THRESHOLD = 20;

    // *** THESE ARE THE MISSING LINES THAT CAUSED THE COMPILER ERROR ***
    private static final String NOTIFICATION_CHANNEL_ID = "com.example.memorycardhelper.FloatingWidgetService";
    private static final int NOTIFICATION_ID = 1;

    private WindowManager windowManager;
    private View floatingWidget;
    private ImageView overlayView;

    private MediaProjectionManager mediaProjectionManager;
    private MediaProjection mediaProjection;
    private VirtualDisplay virtualDisplay;
    private ImageReader imageReader;
    private MediaProjection.Callback mediaProjectionCallback;

    private final ExecutorService backgroundExecutor = Executors.newSingleThreadExecutor();
    private final Handler mainThreadHandler = new Handler(Looper.getMainLooper());

    private Bitmap baseBitmap;
    private Bitmap cumulativeDiffBitmap;
    private Paint diffPaint;

    private ImageButton findDifferenceButton;


    @Override
    public IBinder onBind(Intent intent) { return null; }

    @Override
    public void onCreate() {
        super.onCreate();
        createNotificationChannel();
        Notification notification = new NotificationCompat.Builder(this, NOTIFICATION_CHANNEL_ID)
                .setContentTitle("Memory Card Helper")
                .setContentText("Widget is active.")
                .setSmallIcon(R.mipmap.ic_launcher)
                .build();
        startForeground(NOTIFICATION_ID, notification);
        windowManager = (WindowManager) getSystemService(WINDOW_SERVICE);
        addFloatingWidgetView();

        diffPaint = new Paint();
        diffPaint.setAlpha(255);
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        if (intent == null || intent.getParcelableExtra("data") == null) {
            stopSelf();
            return START_NOT_STICKY;
        }
        int resultCode = intent.getIntExtra("resultCode", -1);
        Intent data = intent.getParcelableExtra("data");
        mediaProjectionManager = (MediaProjectionManager) getSystemService(Context.MEDIA_PROJECTION_SERVICE);
        mediaProjection = mediaProjectionManager.getMediaProjection(resultCode, data);
        mediaProjectionCallback = new MediaProjectionCallback();
        mediaProjection.registerCallback(mediaProjectionCallback, mainThreadHandler);
        setupScreenCapture();
        return START_NOT_STICKY;
    }

    private void addFloatingWidgetView() {
        floatingWidget = LayoutInflater.from(this).inflate(R.layout.floating_widget, null);
        final WindowManager.LayoutParams params = new WindowManager.LayoutParams(
                WindowManager.LayoutParams.WRAP_CONTENT, WindowManager.LayoutParams.WRAP_CONTENT,
                Build.VERSION.SDK_INT >= Build.VERSION_CODES.O ?
                        WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY : WindowManager.LayoutParams.TYPE_PHONE,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE, PixelFormat.TRANSLUCENT);
        params.gravity = Gravity.TOP | Gravity.START;
        params.x = 0;
        params.y = 100;
        windowManager.addView(floatingWidget, params);
        setupWidgetListeners(params);
    }

    private void setupWidgetListeners(final WindowManager.LayoutParams params) {
        floatingWidget.findViewById(R.id.drag_handle).setOnTouchListener(new View.OnTouchListener() {
            private int initialX, initialY;
            private float initialTouchX, initialTouchY;
            @Override
            public boolean onTouch(View v, MotionEvent event) {
                switch (event.getAction()) {
                    case MotionEvent.ACTION_DOWN:
                        initialX = params.x; initialY = params.y;
                        initialTouchX = event.getRawX(); initialTouchY = event.getRawY();
                        return true;
                    case MotionEvent.ACTION_MOVE:
                        params.x = initialX + (int) (event.getRawX() - initialTouchX);
                        params.y = initialY + (int) (event.getRawY() - initialTouchY);
                        windowManager.updateViewLayout(floatingWidget, params);
                        return true;
                }
                return false;
            }
        });
        floatingWidget.findViewById(R.id.button_capture_base).setOnClickListener(v -> captureAndSetBaseImage());
        findDifferenceButton = floatingWidget.findViewById(R.id.button_find_difference);
        findDifferenceButton.setAlpha(0.5f);
        findDifferenceButton.setOnClickListener(v -> {
            if (baseBitmap == null) {
                Toast.makeText(this, "Please capture a base image first.", Toast.LENGTH_SHORT).show();
                return;
            }
            captureAndShowDifference();
        });
        floatingWidget.findViewById(R.id.button_reset).setOnClickListener(v -> resetToIdle());
    }

    private void captureAndShowDifference() {
        Toast.makeText(this, "Finding new differences...", Toast.LENGTH_SHORT).show();
        if (overlayView != null) {
            overlayView.setAlpha(0.0f);
        }

        mainThreadHandler.postDelayed(() -> {
            captureScreen(currentBitmap -> {
                if (currentBitmap != null) {
                    backgroundExecutor.execute(() -> {
                        int width = baseBitmap.getWidth();
                        int height = baseBitmap.getHeight();
                        Bitmap latestDiffBitmap = Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888);
                        compareBitmapsNative(baseBitmap, currentBitmap, latestDiffBitmap, PIXEL_DIFFERENCE_THRESHOLD);
                        currentBitmap.recycle();
                        if (cumulativeDiffBitmap == null) {
                            cumulativeDiffBitmap = Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888);
                        }
                        Canvas canvas = new Canvas(cumulativeDiffBitmap);
                        canvas.drawBitmap(latestDiffBitmap, 0, 0, diffPaint);
                        latestDiffBitmap.recycle();
                        mainThreadHandler.post(() -> showOverlay(cumulativeDiffBitmap));
                    });
                }
            });
        }, 100);
    }

    private void captureAndSetBaseImage() {
        Toast.makeText(this, "Capturing base...", Toast.LENGTH_SHORT).show();
        captureScreen(bitmap -> {
            if (bitmap != null) {
                resetToIdle();
                baseBitmap = bitmap;
                findDifferenceButton.setAlpha(1.0f);
                Toast.makeText(FloatingWidgetService.this, "Base screen captured.", Toast.LENGTH_SHORT).show();
            } else {
                Toast.makeText(FloatingWidgetService.this, "Capture failed.", Toast.LENGTH_SHORT).show();
            }
        });
    }

    private void resetToIdle() {
        if (overlayView != null) {
            overlayView.setAlpha(0.0f);
        }
        if (baseBitmap != null) {
            baseBitmap.recycle();
            baseBitmap = null;
        }
        if (cumulativeDiffBitmap != null) {
            cumulativeDiffBitmap.recycle();
            cumulativeDiffBitmap = null;
        }
        findDifferenceButton.setAlpha(0.5f);
        Toast.makeText(this, "Reset complete.", Toast.LENGTH_SHORT).show();
    }

    private void showOverlay(Bitmap bitmap) {
        if (overlayView == null) {
            overlayView = new ImageView(this);
            WindowManager.LayoutParams overlayParams = new WindowManager.LayoutParams(
                    WindowManager.LayoutParams.MATCH_PARENT, WindowManager.LayoutParams.MATCH_PARENT,
                    Build.VERSION.SDK_INT >= Build.VERSION_CODES.O ?
                            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY : WindowManager.LayoutParams.TYPE_PHONE,
                    WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE | WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE | WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
                    PixelFormat.TRANSLUCENT);
            overlayView.setScaleType(ImageView.ScaleType.FIT_XY);
            windowManager.addView(overlayView, overlayParams);
        }
        overlayView.setImageBitmap(bitmap);
        overlayView.setAlpha(0.7f);
    }

    private void captureScreen(final OnBitmapCapturedListener listener) {
        Image image = null;
        try {
            image = imageReader.acquireLatestImage();
            if (image != null) {
                listener.onBitmapCaptured(imageToBitmap(image));
            } else {
                listener.onBitmapCaptured(null);
            }
        } catch (Exception e) {
            Log.e(TAG, "Capture failed", e);
            listener.onBitmapCaptured(null);
            if (image != null) image.close();
        }
    }

    private Bitmap imageToBitmap(Image image) {
        Image.Plane plane = image.getPlanes()[0];
        ByteBuffer buffer = plane.getBuffer();
        int pixelStride = plane.getPixelStride();
        int rowStride = plane.getRowStride();
        int rowPadding = rowStride - pixelStride * image.getWidth();
        Bitmap tempBitmap = Bitmap.createBitmap(image.getWidth() + rowPadding / pixelStride, image.getHeight(), BITMAP_CONFIG);
        tempBitmap.copyPixelsFromBuffer(buffer);
        Bitmap croppedBitmap = Bitmap.createBitmap(tempBitmap, 0, 0, image.getWidth(), image.getHeight());
        if (tempBitmap != croppedBitmap) {
            tempBitmap.recycle();
        }
        image.close();
        return croppedBitmap;
    }

    private void setupScreenCapture() {
        DisplayMetrics metrics = new DisplayMetrics();
        windowManager.getDefaultDisplay().getRealMetrics(metrics);
        int width = metrics.widthPixels;
        int height = metrics.heightPixels;
        int density = metrics.densityDpi;
        imageReader = ImageReader.newInstance(width, height, PixelFormat.RGBA_8888, 2);
        virtualDisplay = mediaProjection.createVirtualDisplay("ScreenCapture", width, height, density,
                DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR, imageReader.getSurface(), null, null);
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        backgroundExecutor.shutdown();
        stopForeground(true);
        if (virtualDisplay != null) virtualDisplay.release();
        if (mediaProjection != null) mediaProjection.stop();
        if (floatingWidget != null) windowManager.removeView(floatingWidget);
        if (overlayView != null) windowManager.removeView(overlayView);
        if (baseBitmap != null) baseBitmap.recycle();
        if (cumulativeDiffBitmap != null) cumulativeDiffBitmap.recycle();
    }

    private void createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            NotificationChannel channel = new NotificationChannel(NOTIFICATION_CHANNEL_ID, "Floating Widget Service Channel", NotificationManager.IMPORTANCE_LOW);
            getSystemService(NotificationManager.class).createNotificationChannel(channel);
        }
    }

    private class MediaProjectionCallback extends MediaProjection.Callback {
        @Override
        public void onStop() {
            if (mediaProjection != null) {
                mediaProjection.unregisterCallback(this);
                mediaProjection = null;
            }
            if (virtualDisplay != null) virtualDisplay.release();
            stopSelf();
        }
    }

    interface OnBitmapCapturedListener {
        void onBitmapCaptured(Bitmap bitmap);
    }
}